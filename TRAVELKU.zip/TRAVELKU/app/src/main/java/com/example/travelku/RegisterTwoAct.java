package com.example.travelku;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RegisterTwoAct extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_two);
    }
}